//
//  LogIn.swift
//  LoginView_SwiftUI
//
//  Created by Immature Inc on 28/04/2020.
//  Copyright © 2020 AnthonyDesignCode.io. All rights reserved.
//

import SwiftUI

struct LogIn: View {
    
    @State var index = 0
    
    var body: some View {
        VStack {
            Image("logo")
                .resizable()
                .frame(width: 200, height: 200)
            HStack {
                Button(action: {
                    withAnimation(.spring(response: 0.8, dampingFraction: 0.5, blendDuration: 0.5)) {
                        self.index = 0
                    }
                }) {
                    Text("Account Login")
                        .foregroundColor(self.index == 0 ? .black : .white)
                        .fontWeight(.semibold)
                        .padding(.vertical, 10).frame(width: (UIScreen.main.bounds.width - 50) / 2)
                }
                .background(self.index == 0 ? Color.white : Color.clear)
                .clipShape(Capsule())
                
                Button(action: {
                    withAnimation(.spring(response: 0.8, dampingFraction: 0.5, blendDuration: 0.5)) {
                        self.index = 1
                    }
                }) {
                    Text("Create Account")
                        .foregroundColor(self.index == 1 ? .black : .white)
                        .fontWeight(.semibold)
                        .padding(.vertical, 10).frame(width: (UIScreen.main.bounds.width - 50) / 2)
                }
                .background(self.index == 1 ? Color.white : Color.clear)
                .clipShape(Capsule())
            }
            .background(Color.black.opacity(0.1))
            .clipShape(Capsule())
            .padding(.top, 25)
            
            if self.index == 0 {
                logIn()
            } else {
                singIn()
            }
            
            if self.index == 0 {
                Button(action: {
                    // do something
                }){
                    Text("Forgot Password?")
                        .foregroundColor(.white)
                }.padding(.top, 20)
            }
            
            HStack(spacing: 20) {
                Color.white.opacity(0.7)
                    .frame(width: 45, height: 1)
                Text("Or")
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                Color.white.opacity(0.7)
                    .frame(width: 45, height: 1)
            }
            .padding(.top, 10)
            
            HStack {
                Button(action: {
                    // do something
                }) {
                    Image("FaceBook")
                        .renderingMode(.original)
                        .padding()
                }
                .background(Color("Color3"))
                .clipShape(Circle())
                .shadow(radius: 8)
                .padding()
                
                Button(action: {
                    // do something
                }) {
                    Image("Google")
                        .renderingMode(.original)
                        .padding()
                }
                .background(Color("Color3"))
                .clipShape(Circle())
                .shadow(radius: 8)
                .padding()
                
                Button(action: {
                    // do something
                }) {
                    Image("Apple")
                        .renderingMode(.original)
                        .resizable()
                        .frame(width: 28.5, height: 28.5)
                        .padding()
                }
                .background(Color("Color3"))
                .clipShape(Circle())
                .shadow(radius: 8)
                .padding()
            }
            .padding(.top, 10)
        }
        .padding()
    }
}

struct logIn: View {
    
    @State var eMail = ""
    @State var passWord = ""
    
    var body: some View{
        VStack {
            VStack {
                HStack(spacing: 20) {
                    Image(systemName: "envelope")
                        .foregroundColor(.white)
                    TextField("E-Mail Address", text: self.$eMail)
                        .foregroundColor(.white)
                        .keyboardType(.emailAddress)
                }
                .padding(.vertical, 20)
                .foregroundColor(.black)
                
                Divider()
                
                HStack(spacing: 20) {
                    Image(systemName: "lock")
                        .foregroundColor(.white)
                    SecureField("Password", text: self.$passWord)
                        .foregroundColor(.white)
                    Button(action: {
                        // do something
                    }) {
                        Image(systemName: "eye")
                            .foregroundColor(.white)
                    }
                }
                .padding(.vertical, 20)
                .foregroundColor(.black)
            }
            .padding(.vertical)
            .padding(.horizontal, 20)
            .padding(.bottom, 40)
            .background(Color.white.opacity(0.2))
            .cornerRadius(10)
            .padding(.top, 25)
            
            Button(action: {
                // do something
            }) {
                Text("LOGIN")
                    .font(.title)
                    .foregroundColor(.white)
                    .fontWeight(.semibold)
                    .padding(.vertical)
                    .frame(width: UIScreen.main.bounds.width - 100)
            }
            .background(LinearGradient(gradient: .init(colors: [Color("Color"), Color("Color1")]), startPoint: .leading, endPoint: .trailing))
            .cornerRadius(8)
            .offset(y: -40)
            .padding(.bottom, -40)
            .shadow(radius: 15)
        }
    }
}

struct singIn: View {
    
    @State var eMail = ""
    @State var passWord = ""
    @State var repassWord = ""
    
    var body: some View{
        VStack {
            VStack {
                HStack(spacing: 20) {
                    Image(systemName: "envelope")
                        .foregroundColor(.white)
                    TextField("E-Mail Address", text: self.$eMail)
                        .foregroundColor(.white)
                        .keyboardType(.emailAddress)
                }
                .padding(.vertical, 20)
                .foregroundColor(.black)
                
                Divider()
                
                HStack(spacing: 20) {
                    Image(systemName: "lock")
                        .foregroundColor(.white)
                    SecureField("Enter Password", text: self.$passWord)
                        .foregroundColor(.white)
                    
                    Button(action: {
                        // do something
                    }) {
                        Image(systemName: "eye")
                            .foregroundColor(.white)
                    }
                }
                .padding(.vertical, 20)
                
                Divider()
                
                HStack(spacing: 20) {
                    Image(systemName: "lock")
                        .foregroundColor(.white)
                    SecureField("Re-Enter Password", text: self.$repassWord)
                        .foregroundColor(.white)
                    
                    Button(action: {
                        // do something
                    }) {
                        Image(systemName: "eye")
                            .foregroundColor(.white)
                    }
                }
                .padding(.vertical, 20)
            }
            .padding(.vertical)
            .padding(.horizontal, 20)
            .padding(.bottom, 40)
            .background(Color.white.opacity(0.2))
            .cornerRadius(10)
            .padding(.top, 25)
            
            Button(action: {
                // do something
            }) {
                Text("SIGNUP")
                    .font(.title)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .padding(.vertical).frame(width: UIScreen.main.bounds.width - 100)
            }
            .background(LinearGradient(gradient: .init(colors: [Color("Color"), Color("Color1")]), startPoint: .leading, endPoint: .trailing))
            .cornerRadius(8)
            .offset(y: -40)
            .padding(.bottom, -40)
            .shadow(radius: 15)
        }
    }
}
