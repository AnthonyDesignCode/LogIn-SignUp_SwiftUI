//
//  ContentView.swift
//  LoginView_SwiftUI
//
//  Created by AnthonyDesignCode.io on 28/04/2020.
//  Copyright © 2020 AnthonyDesignCode.io. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            LinearGradient(gradient: .init(colors: [Color("Color"), Color("Color2")]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
           
            if UIScreen.main.bounds.height > 900 {
                LogIn()
            } else {
                ScrollView(.vertical, showsIndicators: false) {
                    LogIn()
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
